# -*- coding: utf-8 -*-
{
    'name': "Workshop Management",
    'version': "1.0",
    'catgory': "Tools",
    'summary': "Workshop Management Module",
    'description': "This module manages workshop",
    'author': "Ibrahim",
    'website': "Ibrahim.com",
    'depends': ['base', 'hr', 'mail', 'contacts'],
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'demo': [],
}
