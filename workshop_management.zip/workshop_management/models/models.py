from odoo import fields, models


class workshopMaster(models.Model):
    _name = "workshop.management"
    _description = "Workshop Management"
    _inherit = ['mail.thread', 'mail.mixin']
    _rec_name="name"

    name = fields.Char(string="Workshop Title", required=True)
    instructor_id = fields.Many2one('hr.employee', string="Instructor")
    participants = fields.Many2one('res.partner', string="Participants")
    duration = fields.Float(string="Duration in hours")
    fees = fields.Float(string="Workshop Fees")
    location = fields.Char(string="Workshop Location")
    total_revenue = fields.Float(string="Total Revenue", compute='compute_total_revenue')

    def compute_total_revenue(self):
        for each in self:
            total_revenue = each.fees * each.participants
            print(total_revenue)

    # Paranthesis
    # Exponents
    # Multiplication
    # Division
    # Addition
    # Subtraction
    # PEMDAS

