# -*- coding: utf-8 -*-
{
    'name': "Employee Training",
    'version': "1.0",
    'catgory': 'Tools',
    'summary': "Employee Training Module",
    'description': """Long description of module's purpose""",
    'author': "Ibrahim",
    'website': "https://www.yourcompany.com",
    # any module necessary for this one to work correctly
    'depends': ['base','mail','hr'],
    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    # only loaded in demonstration mode
    'demo': [
    ],
}

