from odoo import fields, models, _
from odoo.exceptions import ValidationError


class TrainingMaster(models.Model):
    _name = 'employee.training'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Employee Training'
    _rec_name = 'name'

    name = fields.Char(string="Training Name")
    trainer = fields.Many2one('hr.employee', string="Trainer")
    trainees = fields.Many2many('hr.employee', string="Trainees", required='True')
    training_schedule = fields.Char(string="Training Schedule")
    additional_requirement = fields.Char(string="Additional Requirements")
    start_date = fields.Datetime(string="Start Date")
    end_date = fields.Datetime(string="End Date")
    progress = fields.Float(string="Progress", default=0.0)

    state = fields.Selection([('not_started', 'Not Started'), ('ongoing', 'Ongoing'), ('completed', 'Completed')],
                             string='State', default='not_started', tracking=True)

    def action_start(self):
        print('Training Started')
        self.state = "ongoing"
        if not self.trainees or not self.trainer or not self.name:
            raise ValidationError(_(
                "You must enter data in the trainees field otherwise you can't transition to the ongoing stage"
            ))

    def action_complete(self):
        print('Complete Training')
        self.state = "completed"
